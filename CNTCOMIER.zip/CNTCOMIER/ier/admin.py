from django.contrib import admin
from .models import Addsubmission, Directorate, Uforce, Partner, Ier, Userinformations, Signaturecentcom, Signaturepartner
# Register your models here.

admin.site.register(Addsubmission)
admin.site.register(Directorate)
admin.site.register(Uforce)
admin.site.register(Partner)
admin.site.register(Ier)
admin.site.register(Userinformations)
admin.site.register(Signaturecentcom)
admin.site.register(Signaturepartner)

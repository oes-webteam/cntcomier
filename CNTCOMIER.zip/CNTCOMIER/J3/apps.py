from django.apps import AppConfig


class J3Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'J3'

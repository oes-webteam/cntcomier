from django.contrib import admin
from . models import Addsubmission, J6
# Register your models here.

admin.site.register(Addsubmission)
admin.site.register(J6)

from django.contrib import admin
from . models import Strategies, Addsubmission

admin.site.register(Strategies)
admin.site.register(Addsubmission)

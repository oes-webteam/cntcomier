from django.contrib import admin
from .models import Addsubmission, Intell
# Register your models here.
admin.site.register(Intell)
admin.site.register(Addsubmission)

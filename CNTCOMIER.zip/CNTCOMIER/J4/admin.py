from django.contrib import admin
from . models import Logistic, Addsubmission
# Register your models here.

admin.site.register(Addsubmission)
admin.site.register(Logistic)

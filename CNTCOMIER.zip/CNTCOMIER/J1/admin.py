from django.contrib import admin
from .models import Addsubmission, Humanresources
# Register your models here.


admin.site.register(Addsubmission)
admin.site.register(Humanresources)

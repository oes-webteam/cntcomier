from django.apps import AppConfig


class CccnConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CCCN'
